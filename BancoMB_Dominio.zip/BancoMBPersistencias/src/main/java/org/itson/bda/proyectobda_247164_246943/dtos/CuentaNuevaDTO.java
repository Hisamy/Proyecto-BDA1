
package org.itson.bda.proyectobda_247164_246943.dtos;

import java.sql.Date;


public class CuentaNuevaDTO {
    private Integer numeroCuenta;
    private Date fechaApertura;
    private Double saldo;

    public Integer getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(Integer numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public Date getFechaApertura() {
        return fechaApertura;
    }

    public void setFechaApertura(Date fechaApertura) {
        this.fechaApertura = fechaApertura;
    }

    public Double getSaldo() {
        return saldo;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }

  
    
    
}
