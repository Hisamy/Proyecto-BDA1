
package org.itson.bda.proyectobda_247164_246943.dtos;


public class TransaccionNuevaDTO {
    private int folio;
    private float monto;

    public int getFolio() {
        return folio;
    }

    public void setFolio(int folio) {
        this.folio = folio;
    }

    public float getMonto() {
        return monto;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }
    
    
}
