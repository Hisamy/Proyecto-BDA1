
package org.itson.bda.proyectobda_247164_246943.daos;


public class DomiciliosDAO {
    
}
