
package org.itson.bda.BancoMB.bancoMB.dlg;

// Enumeración llamada Acciones
public enum Acciones {
    // Constante que representa la acción de aceptar
    ACEPTAR,
    // Constante que representa la acción de aceptar  
    CANCELAR
}
