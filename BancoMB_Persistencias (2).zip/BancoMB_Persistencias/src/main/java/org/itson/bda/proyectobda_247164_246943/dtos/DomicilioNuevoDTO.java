
package org.itson.bda.proyectobda_247164_246943.dtos;


public class DomicilioNuevoDTO {
    private int numeroDomicilio;
    private String calle, colonia;
    private int CP;

    public int getNumeroDomicilio() {
        return numeroDomicilio;
    }

    public void setNumeroDomicilio(int numeroDomicilio) {
        this.numeroDomicilio = numeroDomicilio;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getColonia() {
        return colonia;
    }

    public void setColonia(String colonia) {
        this.colonia = colonia;
    }

    public int getCP() {
        return CP;
    }

    public void setCP(int CP) {
        this.CP = CP;
    }
    
    
}
